"""
This module provide Alignak current version
"""

VERSION = "1.0.0"
