"""
This module provide Alignak current version
"""

VERSION = "0.2"
